create function pg_catalog.anytextcat(anynonarray, text) returns text
LANGUAGE SQL
AS $$
select $1::pg_catalog.text || $2
$$;

create function pg_catalog.interval_pl_date(interval, date) returns timestamp without time zone
LANGUAGE SQL
AS $$
select $2 + $1
$$;
